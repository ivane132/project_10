from django.db import models

# Create your models here.
class category(models.Model):
    name = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
    
    
class post(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    category = models.ForeignKey(category, on_delete=models.CASCADE)

    def __str__(self):
        return self.title
    
class comment(models.Model):
    content = models.TextField()
    post = models.ForeignKey(post, on_delete=models.CASCADE)

    def __str__(self):
        return self.content[20:40]