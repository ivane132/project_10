from rest_framework import serializers
from .models import category, post, comment


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = category
        fields = '__all__'


class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = post
        fields = '__all__'


class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = comment
        fields = '__all__'

